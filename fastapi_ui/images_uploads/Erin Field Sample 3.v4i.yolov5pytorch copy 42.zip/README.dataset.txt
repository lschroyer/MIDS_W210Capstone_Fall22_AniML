# Erin Field Sample 3 > 2022-10-23 12:14pm
https://universe.roboflow.com/object-detection/erin-field-sample-3

Provided by Roboflow
License: CC BY 4.0

